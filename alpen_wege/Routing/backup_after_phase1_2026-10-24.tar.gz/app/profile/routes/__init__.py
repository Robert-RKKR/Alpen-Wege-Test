from fastapi import APIRouter

from . import access_policy, resource_type
from .auth import router as auth_actions_router
from .user import router as user_router

auth_router = APIRouter(prefix="/auth", tags=["Auth"])
auth_router.include_router(auth_actions_router)
auth_router.include_router(resource_type.router)
auth_router.include_router(access_policy.router)

users_router = APIRouter(prefix="/users", tags=["Users"])
users_router.include_router(user_router)

router = APIRouter()
router.include_router(auth_router)
router.include_router(users_router)
