# Standard library
import logging
from uuid import UUID

# Third-party
from fastapi import APIRouter, Depends, File, Form, Response, UploadFile, status
from geoalchemy2.functions import ST_AsGeoJSON
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.concurrency import run_in_threadpool

# Local application
from app.config import get_settings
from app.core.dependencies import get_db
from app.management.utils.event_logger import log_created, log_updated
from app.core.utils.responses import ApiResponse, AppError, ok, ok_list, fail
from app.profile.permissions import resource_access, AccessContext, check_object_access
from app.explorer.models.models_agg.track import ExplorerAggTrack
from app.explorer.models.models_sub.geo_record import ExplorerSubGeoRecord
from app.explorer.models.models_sub.geo_performance import ExplorerSubGeoPerformance
from app.assets.models.models_agg.gpx import AssetAggGpx
from app.explorer.schemas.track import (
    TrackCreated,
    TrackGeometry,
    TrackListItem,
    TrackMetrics,
    TrackPerformance,
    TrackRead,
    TrackUpdate,
)
from app.explorer.services.gpx.errors import GpxProcessingError
from app.explorer.services.gpx.xml_guard import check_gpx_root
from app.explorer.services.gpx_storage import (
    UploadTooLarge,
    delete_quietly,
    save_upload,
)
from app.explorer.services.dispatch import (
    enqueue_detect_pois,
    enqueue_process_track,
    request_stats_recompute,
)
from app.management.jobs.events import publish_job_event_async
from app.management.jobs.kinds import JobKind, TASK_NAME
from app.management.jobs.service import create_job, get_or_create_active_job
from app.management.schemas.job import JobAccepted

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/tracks", tags=["Explorer - Track"])
settings = get_settings()


def _apply_scope(stmt, access: AccessContext):
    if access.scope == "own":
        stmt = stmt.where(ExplorerAggTrack.created_by == access.user.id)
    elif access.scope == "public":
        stmt = stmt.where(
            (ExplorerAggTrack.created_by == access.user.id)
            | (ExplorerAggTrack.is_public == True)  # noqa: E712
        )
    return stmt


def _apply_visibility(stmt, access: AccessContext, archived: bool):
    if archived:
        stmt = stmt.where(ExplorerAggTrack.archived_at.isnot(None))
        if access.scope != "all":
            stmt = stmt.where(ExplorerAggTrack.created_by == access.user.id)
    else:
        stmt = stmt.where(ExplorerAggTrack.archived_at.is_(None))

    if access.scope not in ("own", "all"):
        stmt = stmt.where(
            (ExplorerAggTrack.created_by == access.user.id)
            | (ExplorerAggTrack.processing_status == "ready")
        )

    return stmt


def _ensure_visible(access: AccessContext, track: ExplorerAggTrack):
    if access.scope == "all":
        return
    if track.created_by == access.user.id:
        return
    if track.processing_status != "ready" or track.archived_at is not None:
        raise AppError(404, "Not found")


def _build_metrics(geo_record, geo_perf) -> TrackMetrics | None:
    if geo_record is None:
        return None
    return TrackMetrics(
        distance_m=geo_record.distance_m,
        elevation_gain_m=geo_record.elevation_gain_m,
        elevation_loss_m=geo_record.elevation_loss_m,
        highest_elevation_m=geo_record.highest_elevation_m,
        lowest_elevation_m=geo_record.lowest_elevation_m,
        total_time_s=geo_perf.total_time_s if geo_perf else None,
        moving_time_s=geo_perf.moving_time_s if geo_perf else None,
    )


# --- POST /tracks ---

@router.post("", response_model=ApiResponse[TrackCreated], status_code=status.HTTP_202_ACCEPTED)
async def create_track(
    response: Response,
    name: str = Form(..., min_length=1, max_length=255),
    gpx_file: UploadFile = File(...),
    summary: str | None = Form(None, max_length=1000),
    description: str | None = Form(None, max_length=10000),
    is_public: bool = Form(False),
    access: AccessContext = Depends(resource_access("track", "create")),
    db: AsyncSession = Depends(get_db),
):
    filename = gpx_file.filename or ""
    if not filename.lower().endswith(".gpx"):
        raise AppError(400, "Only .gpx files are accepted.")

    try:
        await run_in_threadpool(check_gpx_root, gpx_file.file)
        gpx_file.file.seek(0)
    except GpxProcessingError:
        raise AppError(400, "Not a valid GPX file.")

    max_bytes = settings.GPX_MAX_UPLOAD_MB * 1024 * 1024
    try:
        stored = await run_in_threadpool(save_upload, gpx_file.file, max_bytes=max_bytes)
    except UploadTooLarge:
        raise AppError(413, f"File too large (maximum {settings.GPX_MAX_UPLOAD_MB} MB).")

    relative_path = stored.relative_path
    try:
        dup_stmt = (
            select(ExplorerAggTrack.id)
            .join(AssetAggGpx, AssetAggGpx.id == ExplorerAggTrack.gpx_id)
            .where(
                ExplorerAggTrack.created_by == access.user.id,
                ExplorerAggTrack.archived_at.is_(None),
                AssetAggGpx.sha256 == stored.sha256,
            )
            .order_by(ExplorerAggTrack.created_at.desc())
            .limit(1)
        )
        dup_result = await db.execute(dup_stmt)
        duplicate_of = dup_result.scalar_one_or_none()

        gpx = AssetAggGpx(
            name=filename[:255],
            path=relative_path,
            sha256=stored.sha256,
            size_bytes=stored.size_bytes,
            created_by=access.user.id,
            is_public=False,
        )
        db.add(gpx)
        await db.flush()

        track = ExplorerAggTrack(
            name=name,
            summary=summary or None,
            description=description or None,
            is_public=is_public,
            gpx_id=gpx.id,
            processing_status="pending",
            created_by=access.user.id,
        )
        db.add(track)
        await db.flush()
        log_created(db, track, access.user.id)
        job = await create_job(
            db, user_id=access.user.id, kind=JobKind.TRACK_PROCESS,
            task_name=TASK_NAME[JobKind.TRACK_PROCESS],
            subject_type="track", subject_id=track.id,
        )
        await db.commit()
    except Exception:
        await run_in_threadpool(delete_quietly, relative_path)
        raise

    await publish_job_event_async(job)
    try:
        await run_in_threadpool(enqueue_process_track, track.id, job["id"])
    except Exception:
        # the track stays pending and its job queued; the reaper enqueues it again
        logger.warning("Failed to enqueue processing for track %s", track.id)

    response.headers["Location"] = f"/api/v1/jobs/{job['id']}"
    result = TrackCreated(
        id=track.id,
        name=track.name,
        processing_status=track.processing_status,
        created_at=track.created_at,
        duplicate_of_track_id=duplicate_of,
        job_id=job["id"],
    )
    return ok(result, code=202, message="Accepted")


# --- GET /tracks ---

@router.get("", response_model=ApiResponse[list[TrackListItem]])
async def list_tracks(
    limit: int = 100,
    offset: int = 0,
    archived: bool = False,
    processing_status: str | None = None,
    sport_type_id: UUID | None = None,
    access: AccessContext = Depends(resource_access("track", "read")),
    db: AsyncSession = Depends(get_db),
):
    if limit > 500:
        limit = 500

    if processing_status and processing_status not in (
        "pending", "processing", "ready", "failed"
    ):
        raise AppError(422, f"Invalid processing_status: {processing_status}")

    base = select(ExplorerAggTrack)
    base = _apply_scope(base, access)
    base = _apply_visibility(base, access, archived)

    if processing_status:
        base = base.where(ExplorerAggTrack.processing_status == processing_status)
    if sport_type_id:
        base = base.where(ExplorerAggTrack.sport_type_id == sport_type_id)

    count_stmt = select(func.count()).select_from(base.subquery())
    total = (await db.execute(count_stmt)).scalar_one()

    stmt = (
        base.outerjoin(
            ExplorerSubGeoRecord,
            ExplorerSubGeoRecord.id == ExplorerAggTrack.geo_record_id,
        )
        .outerjoin(
            ExplorerSubGeoPerformance,
            ExplorerSubGeoPerformance.id == ExplorerSubGeoRecord.geo_performance_id,
        )
        .add_columns(ExplorerSubGeoRecord, ExplorerSubGeoPerformance)
        .order_by(
            func.coalesce(ExplorerAggTrack.recorded_at, ExplorerAggTrack.created_at).desc()
        )
        .limit(limit)
        .offset(offset)
    )
    rows = (await db.execute(stmt)).all()

    items = []
    for track, geo_rec, geo_perf in rows:
        item = TrackListItem(
            id=track.id,
            name=track.name,
            summary=track.summary,
            is_public=track.is_public,
            sport_type_id=track.sport_type_id,
            recorded_at=track.recorded_at,
            created_at=track.created_at,
            processing_status=track.processing_status,
            archived_at=track.archived_at,
            created_by=track.created_by,
            metrics=_build_metrics(geo_rec, geo_perf),
        )
        items.append(item)

    return ok_list(items, total=total, limit=limit, offset=offset)


# --- GET /tracks/{id} ---

@router.get("/{track_id}", response_model=ApiResponse[TrackRead])
async def get_track(
    track_id: UUID,
    access: AccessContext = Depends(resource_access("track", "read")),
    db: AsyncSession = Depends(get_db),
):
    track = await db.get(ExplorerAggTrack, track_id)
    check_object_access(access, track, not_found_msg="Track not found")
    _ensure_visible(access, track)

    geo_rec = None
    geo_perf = None
    if track.geo_record_id:
        geo_rec = await db.get(ExplorerSubGeoRecord, track.geo_record_id)
        if geo_rec and geo_rec.geo_performance_id:
            geo_perf = await db.get(
                ExplorerSubGeoPerformance, geo_rec.geo_performance_id
            )

    result = TrackRead(
        id=track.id,
        name=track.name,
        name_de=track.name_de,
        name_pl=track.name_pl,
        summary=track.summary,
        summary_de=track.summary_de,
        summary_pl=track.summary_pl,
        description=track.description,
        description_de=track.description_de,
        description_pl=track.description_pl,
        is_public=track.is_public,
        processing_status=track.processing_status,
        processing_error=track.processing_error,
        processing_warnings=track.processing_warnings,
        processed_at=track.processed_at,
        recorded_at=track.recorded_at,
        archived_at=track.archived_at,
        sport_type_id=track.sport_type_id,
        difficulty_level_id=track.difficulty_level_id,
        difficulty_sport_id=track.difficulty_sport_id,
        start_poi_id=track.start_poi_id,
        end_poi_id=track.end_poi_id,
        geo_record_id=track.geo_record_id,
        gpx_id=track.gpx_id,
        created_at=track.created_at,
        updated_at=track.updated_at,
        created_by=track.created_by,
        metrics=_build_metrics(geo_rec, geo_perf),
    )
    return ok(result)


# --- GET /tracks/{id}/geometry ---

@router.get("/{track_id}/geometry", response_model=ApiResponse[TrackGeometry])
async def get_track_geometry(
    track_id: UUID,
    access: AccessContext = Depends(resource_access("track", "read")),
    db: AsyncSession = Depends(get_db),
):
    track = await db.get(ExplorerAggTrack, track_id)
    check_object_access(access, track, not_found_msg="Track not found")
    _ensure_visible(access, track)

    if track.processing_status != "ready" or not track.geo_record_id:
        raise AppError(404, "Geometry not available yet.")

    stmt = select(
        ExplorerSubGeoRecord.geojson,
        ExplorerSubGeoRecord.elevation_graph,
        ExplorerSubGeoRecord.geo_performance_id,
        ST_AsGeoJSON(ExplorerSubGeoRecord.start_location).label("start_geojson"),
        ST_AsGeoJSON(ExplorerSubGeoRecord.end_location).label("end_geojson"),
    ).where(ExplorerSubGeoRecord.id == track.geo_record_id)
    row = (await db.execute(stmt)).one_or_none()

    if not row:
        raise AppError(404, "Geometry not found.")

    import json as json_mod

    heart_graph = None
    speed_pattern = None
    if row.geo_performance_id:
        perf = await db.get(ExplorerSubGeoPerformance, row.geo_performance_id)
        if perf:
            heart_graph = perf.heart_graph
            speed_pattern = perf.speed_pattern

    start_loc = json_mod.loads(row.start_geojson) if row.start_geojson else None
    end_loc = json_mod.loads(row.end_geojson) if row.end_geojson else None

    result = TrackGeometry(
        geojson=row.geojson,
        elevation_graph=row.elevation_graph,
        heart_graph=heart_graph,
        speed_pattern=speed_pattern,
        start_location=start_loc,
        end_location=end_loc,
    )
    return ok(result)


# --- GET /tracks/{id}/performance ---

@router.get("/{track_id}/performance", response_model=ApiResponse[TrackPerformance])
async def get_track_performance(
    track_id: UUID,
    access: AccessContext = Depends(resource_access("track", "read")),
    db: AsyncSession = Depends(get_db),
):
    track = await db.get(ExplorerAggTrack, track_id)
    check_object_access(access, track, not_found_msg="Track not found")
    _ensure_visible(access, track)

    if not track.geo_record_id:
        raise AppError(404, "Performance data not available.")

    geo_rec = await db.get(ExplorerSubGeoRecord, track.geo_record_id)
    if not geo_rec or not geo_rec.geo_performance_id:
        raise AppError(404, "Performance data not available.")

    perf = await db.get(ExplorerSubGeoPerformance, geo_rec.geo_performance_id)
    if not perf:
        raise AppError(404, "Performance data not available.")

    return ok(TrackPerformance.model_validate(perf))


# --- PATCH /tracks/{id} ---

@router.patch("/{track_id}", response_model=ApiResponse[TrackRead])
async def update_track(
    track_id: UUID,
    body: TrackUpdate,
    access: AccessContext = Depends(resource_access("track", "update")),
    db: AsyncSession = Depends(get_db),
):
    track = await db.get(ExplorerAggTrack, track_id)
    check_object_access(access, track, not_found_msg="Track not found")
    _ensure_visible(access, track)

    changes = body.model_dump(exclude_unset=True)
    old_values = {f: getattr(track, f) for f in changes}

    for field, value in changes.items():
        setattr(track, field, value)

    log_updated(db, track, old_values, changes, access.user.id)
    await db.commit()
    await db.refresh(track)

    sport_changed = (
        "sport_type_id" in changes
        and old_values.get("sport_type_id") != track.sport_type_id
    )
    if sport_changed:
        try:
            await run_in_threadpool(request_stats_recompute, track.created_by)
        except Exception:
            logger.warning("Failed to request stats recompute after sport change")

    geo_rec = None
    geo_perf = None
    if track.geo_record_id:
        geo_rec = await db.get(ExplorerSubGeoRecord, track.geo_record_id)
        if geo_rec and geo_rec.geo_performance_id:
            geo_perf = await db.get(
                ExplorerSubGeoPerformance, geo_rec.geo_performance_id
            )

    result = TrackRead(
        id=track.id,
        name=track.name,
        name_de=track.name_de,
        name_pl=track.name_pl,
        summary=track.summary,
        summary_de=track.summary_de,
        summary_pl=track.summary_pl,
        description=track.description,
        description_de=track.description_de,
        description_pl=track.description_pl,
        is_public=track.is_public,
        processing_status=track.processing_status,
        processing_error=track.processing_error,
        processing_warnings=track.processing_warnings,
        processed_at=track.processed_at,
        recorded_at=track.recorded_at,
        archived_at=track.archived_at,
        sport_type_id=track.sport_type_id,
        difficulty_level_id=track.difficulty_level_id,
        difficulty_sport_id=track.difficulty_sport_id,
        start_poi_id=track.start_poi_id,
        end_poi_id=track.end_poi_id,
        geo_record_id=track.geo_record_id,
        gpx_id=track.gpx_id,
        created_at=track.created_at,
        updated_at=track.updated_at,
        created_by=track.created_by,
        metrics=_build_metrics(geo_rec, geo_perf),
    )
    return ok(result)


# --- DELETE /tracks/{id} (archive) ---

@router.delete("/{track_id}", response_model=ApiResponse[None])
async def archive_track(
    track_id: UUID,
    access: AccessContext = Depends(resource_access("track", "delete")),
    db: AsyncSession = Depends(get_db),
):
    track = await db.get(ExplorerAggTrack, track_id)
    check_object_access(access, track, not_found_msg="Track not found")

    if track.archived_at is None:
        from datetime import datetime, timezone

        old_values = {"archived_at": None}
        track.archived_at = datetime.now(timezone.utc)
        log_updated(
            db, track, old_values, {"archived_at": track.archived_at}, access.user.id
        )
        await db.commit()

        try:
            await run_in_threadpool(request_stats_recompute, track.created_by)
        except Exception:
            logger.warning("Failed to request stats recompute after archive")

    return ok(None, message="Archived")


# --- POST /tracks/{id}/restore ---

@router.post("/{track_id}/restore", response_model=ApiResponse[None])
async def restore_track(
    track_id: UUID,
    access: AccessContext = Depends(resource_access("track", "update")),
    db: AsyncSession = Depends(get_db),
):
    track = await db.get(ExplorerAggTrack, track_id)
    check_object_access(access, track, not_found_msg="Track not found")

    if track.archived_at is not None:
        old_values = {"archived_at": track.archived_at}
        track.archived_at = None
        log_updated(
            db, track, old_values, {"archived_at": None}, access.user.id
        )
        await db.commit()

        try:
            await run_in_threadpool(request_stats_recompute, track.created_by)
        except Exception:
            logger.warning("Failed to request stats recompute after restore")

        if track.processing_status == "pending":
            try:
                job, created = await get_or_create_active_job(
                    db, user_id=track.created_by, kind=JobKind.TRACK_PROCESS,
                    task_name=TASK_NAME[JobKind.TRACK_PROCESS],
                    subject_type="track", subject_id=track.id,
                )
                await db.commit()
                if created:
                    await publish_job_event_async(job)
                await run_in_threadpool(enqueue_process_track, track.id, job["id"])
            except Exception:
                logger.warning("Failed to enqueue processing after restore of track %s", track.id)
        elif track.processing_status == "ready":
            try:
                await run_in_threadpool(enqueue_detect_pois, track.id)
            except Exception:
                pass

    return ok(None, message="Restored")


# --- POST /tracks/{id}/reprocess ---

@router.post(
    "/{track_id}/reprocess",
    response_model=ApiResponse[JobAccepted],
    status_code=status.HTTP_202_ACCEPTED,
)
async def reprocess_track(
    track_id: UUID,
    response: Response,
    access: AccessContext = Depends(resource_access("track", "update")),
    db: AsyncSession = Depends(get_db),
):
    track = await db.get(ExplorerAggTrack, track_id)
    check_object_access(access, track, not_found_msg="Track not found")

    if track.processing_status != "failed":
        raise AppError(409, "Only failed tracks can be reprocessed.")

    track.processing_status = "pending"
    track.processing_error = None
    track.processing_started_at = None
    # the failed attempt's job is terminal, so this creates a new job and keeps the old one as history
    job, created = await get_or_create_active_job(
        db, user_id=track.created_by, kind=JobKind.TRACK_PROCESS,
        task_name=TASK_NAME[JobKind.TRACK_PROCESS],
        subject_type="track", subject_id=track.id,
    )
    await db.commit()
    if created:
        await publish_job_event_async(job)

    try:
        await run_in_threadpool(enqueue_process_track, track.id, job["id"])
    except Exception:
        logger.warning("Failed to enqueue reprocess for track %s", track.id)

    # GET /jobs/{id} is owner-only: Location is only useful to the owner. An administrator
    # reprocessing someone else's track reads the job through /management/jobs/{id}.
    if track.created_by == access.user.id:
        response.headers["Location"] = f"/api/v1/jobs/{job['id']}"
    return ok(JobAccepted(job_id=job["id"]), code=202, message="Reprocessing queued")
