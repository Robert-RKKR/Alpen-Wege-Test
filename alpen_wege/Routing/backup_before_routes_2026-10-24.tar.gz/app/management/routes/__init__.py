# Third-party
from fastapi import APIRouter

# Local application
from .admin_jobs import router as admin_jobs_router
from .broadcast import router as broadcast_router
from .celery import router as celery_router
from .event_log import router as event_log_router
from .jobs import router as jobs_router
from .settings import router as settings_router
from .ws import router as ws_router

# Administrator-only routes live under /management; user routes (jobs, WebSocket) are
# added to `router` directly.
admin_router = APIRouter(prefix="/management")
admin_router.include_router(event_log_router)
admin_router.include_router(settings_router)
admin_router.include_router(admin_jobs_router)
admin_router.include_router(broadcast_router)
admin_router.include_router(celery_router)

router = APIRouter()
router.include_router(jobs_router)
router.include_router(ws_router)
router.include_router(admin_router)
