from uuid import UUID

from fastapi import APIRouter, Depends, File, Response, UploadFile, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from starlette.concurrency import run_in_threadpool

from app.core.dependencies import get_db
from app.core.utils.csv_import import CsvImportResult, csv_upload_description, import_csv
from app.management.utils.event_logger import log_created, log_updated, log_deleted
from app.core.utils.responses import ApiResponse, AppError, ok, ok_list
from app.profile.permissions import resource_access, AccessContext, check_object_access
from app.compendium.models.models_cat.card import CompendiumCatCard
from app.compendium.schemas.card import CardCreate, CardRead, CardUpdate
from app.redis import get_redis_pool
from app.explorer.services.dispatch import enqueue_rescan_card
from app.management.jobs.events import publish_job_event_async
from app.management.jobs.kinds import JobKind, TASK_NAME
from app.management.jobs.service import create_job, fail_active_jobs_for_subject, fail_job
from app.management.schemas.job import JobAccepted

router = APIRouter(prefix="/cards", tags=["Compendium - Card"])

_EAGER = [
    selectinload(CompendiumCatCard.rarity),
    selectinload(CompendiumCatCard.compendium_type),
    selectinload(CompendiumCatCard.poi),
]


def _apply_scope(stmt, model, access: AccessContext):
    if access.scope == "own":
        stmt = stmt.where(model.created_by == access.user.id)
    elif access.scope == "public":
        stmt = stmt.where(
            (model.created_by == access.user.id) | (model.is_public == True)
        )
    return stmt


@router.get("", response_model=ApiResponse[list[CardRead]])
async def list_cards(
    limit: int = 1000,
    offset: int = 0,
    access: AccessContext = Depends(resource_access("card", "read")),
    db: AsyncSession = Depends(get_db),
):
    count_stmt = select(func.count()).select_from(CompendiumCatCard)
    count_stmt = _apply_scope(count_stmt, CompendiumCatCard, access)
    total = (await db.execute(count_stmt)).scalar()
    stmt = select(CompendiumCatCard).options(*_EAGER).order_by(CompendiumCatCard.name).limit(limit).offset(offset)
    stmt = _apply_scope(stmt, CompendiumCatCard, access)
    result = await db.execute(stmt)
    items = result.scalars().all()
    return ok_list(items, total=total, limit=limit, offset=offset)


@router.post("", response_model=ApiResponse[CardRead], status_code=status.HTTP_201_CREATED)
async def create_card(
    body: CardCreate,
    access: AccessContext = Depends(resource_access("card", "create")),
    db: AsyncSession = Depends(get_db),
):
    obj = CompendiumCatCard(**body.model_dump(exclude_unset=True), created_by=access.user.id)
    db.add(obj)
    await db.flush()
    log_created(db, obj, access.user.id)
    await db.commit()
    stmt = (
        select(CompendiumCatCard)
        .where(CompendiumCatCard.id == obj.id)
        .options(*_EAGER)
    )
    result = await db.execute(stmt)
    return ok(result.scalar_one(), code=201, message="Created")


@router.get("/{card_id}", response_model=ApiResponse[CardRead])
async def get_card(
    card_id: UUID,
    access: AccessContext = Depends(resource_access("card", "read")),
    db: AsyncSession = Depends(get_db),
):
    stmt = (
        select(CompendiumCatCard)
        .where(CompendiumCatCard.id == card_id)
        .options(*_EAGER)
    )
    result = await db.execute(stmt)
    obj = result.scalar_one_or_none()
    check_object_access(access, obj, not_found_msg="Card not found")
    return ok(obj)


@router.patch("/{card_id}", response_model=ApiResponse[CardRead])
async def update_card(
    card_id: UUID,
    body: CardUpdate,
    access: AccessContext = Depends(resource_access("card", "update")),
    db: AsyncSession = Depends(get_db),
):
    obj = await db.get(CompendiumCatCard, card_id)
    check_object_access(access, obj, not_found_msg="Card not found")
    changes = body.model_dump(exclude_unset=True)
    old_values = {f: getattr(obj, f) for f in changes}
    for field, value in changes.items():
        setattr(obj, field, value)
    log_updated(db, obj, old_values, changes, access.user.id)
    await db.commit()
    stmt = (
        select(CompendiumCatCard)
        .where(CompendiumCatCard.id == card_id)
        .options(*_EAGER)
    )
    result = await db.execute(stmt)
    return ok(result.scalar_one())


@router.delete("/{card_id}", response_model=ApiResponse[None])
async def delete_card(
    card_id: UUID,
    access: AccessContext = Depends(resource_access("card", "delete")),
    db: AsyncSession = Depends(get_db),
):
    obj = await db.get(CompendiumCatCard, card_id)
    check_object_access(access, obj, not_found_msg="Card not found")
    log_deleted(db, obj, access.user.id)
    await db.delete(obj)
    await db.commit()
    return ok(None, message="Deleted")


@router.post(
    "/{card_id}/rescan",
    response_model=ApiResponse[JobAccepted],
    status_code=status.HTTP_202_ACCEPTED,
)
async def rescan_card(
    card_id: UUID,
    response: Response,
    access: AccessContext = Depends(resource_access("card", "update")),
    db: AsyncSession = Depends(get_db),
):
    obj = await db.get(CompendiumCatCard, card_id)
    check_object_access(access, obj, not_found_msg="Card not found")

    from app.config import get_settings
    settings = get_settings()

    redis = get_redis_pool()
    lock_key = f"rescan:card:{card_id}"
    locked = await redis.set(lock_key, "1", nx=True, ex=settings.RESCAN_LOCK_SECONDS)
    if not locked:
        raise AppError(409, "Rescan already queued.")

    try:
        # We hold the lock, so no rescan of this card can be running: a leftover active job
        # (hard-killed task, lost message) must not block this one through the unique index.
        leftovers = await fail_active_jobs_for_subject(
            db, kind=JobKind.CARD_RESCAN, subject_type="card", subject_id=card_id,
            message="The rescan did not finish.",
        )
        job = await create_job(
            db, user_id=access.user.id, kind=JobKind.CARD_RESCAN,
            task_name=TASK_NAME[JobKind.CARD_RESCAN],
            subject_type="card", subject_id=card_id,
        )
        await db.commit()
    except Exception:
        await redis.delete(lock_key)
        raise AppError(503, "Failed to create the rescan job.")

    for leftover in leftovers:
        await publish_job_event_async(leftover)
    await publish_job_event_async(job)
    try:
        await run_in_threadpool(enqueue_rescan_card, card_id, job["id"])
    except Exception:
        await redis.delete(lock_key)
        failed = await fail_job(db, job["id"], "The rescan could not be queued.")
        await db.commit()
        if failed is not None:
            await publish_job_event_async(failed)
        raise AppError(503, "Failed to enqueue rescan.")

    response.headers["Location"] = f"/api/v1/jobs/{job['id']}"
    return ok(JobAccepted(job_id=job["id"]), code=202, message="Rescan queued")


@router.post(
    "/upload-csv",
    response_model=ApiResponse[CsvImportResult],
    summary="Import cards from CSV",
    description=csv_upload_description(CompendiumCatCard),
)
async def upload_csv(
    file: UploadFile = File(..., description="CSV file with header row"),
    access: AccessContext = Depends(resource_access("card", "create")),
    db: AsyncSession = Depends(get_db),
):
    result = await import_csv(file, CompendiumCatCard, access.user.id, db)
    return ok(result, code=201, message="Import complete")
