# Third-party
from fastapi import APIRouter

router = APIRouter(prefix="/users", tags=["Users"])
