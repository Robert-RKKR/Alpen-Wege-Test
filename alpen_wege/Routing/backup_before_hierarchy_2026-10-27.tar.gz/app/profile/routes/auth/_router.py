# Third-party
from fastapi import APIRouter

router = APIRouter(prefix="/auth", tags=["Auth"])
