from fastapi import Depends, File, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.assets.services.photo_access import csv_photo_check
from app.core.dependencies import get_db
from app.core.utils.responses import ApiResponse, ok
from app.core.utils.csv_import import CsvImportResult, csv_upload_description, import_csv
from app.profile.permissions import resource_access, AccessContext
from app.compendium.models.models_cat.poi import CompendiumCatPoi

from ._router import router


@router.post(
    "/upload-csv",
    response_model=ApiResponse[CsvImportResult],
    summary="Import POIs from CSV",
    description=csv_upload_description(CompendiumCatPoi),
)
async def upload_csv(
    file: UploadFile = File(..., description="CSV file with header row"),
    access: AccessContext = Depends(resource_access("poi", "create")),
    db: AsyncSession = Depends(get_db),
):
    result = await import_csv(file, CompendiumCatPoi, access.user.id, db, row_check=csv_photo_check(db, access.user))
    return ok(result, code=201, message="Import complete")
